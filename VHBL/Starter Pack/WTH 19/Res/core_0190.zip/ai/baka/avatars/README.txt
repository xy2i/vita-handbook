you can put AI avatars in this folder.
they have to be 35x50 pixels, and in jpeg format.

The naming convention is avatarXX.jpg , where XX is the number of the associated deck.
For example, avatar1.jpg will be the avatar associated to deck1.txt